//global variables that will store the toolboxm colour palette
//amnd the helper functions


var socket;
var button;
var slider;

function setup() {

    //create a canvas to fill the content div from index.html
//    canvasContainer = $('#content');
//    var c = createCanvas(canvasContainer.innerWidth(), canvasContainer.innerHeight());
//    c.parent("content");

    createCanvas(700, 600);
	background(211,211,211);
	
	
  button = createButton('Change Background');
  button.position(500, 20);
  button.mousePressed(changeBack);

  slider = createSlider(0, 255, 40);
  slider.position(500, 80);
	
//	//sockets
//	pleasework = 'process.env.PORT' || 3000
//	socket = io.connect(pleasework);
	socket = io.connect('http://localhost:3000');
	socket.on('mouse', newDrawing);
}
	
function newDrawing(data) {
	var red = random(255);
	noStroke();
	fill(red,0,0);
	ellipse(data.x, data.y, slider.value(),slider.value());

}

function mouseDragged() {
	console.log("Send: " + mouseX + ',' + mouseY)
		var data = {
		x: mouseX,
		y: mouseY
	}
	socket.emit('mouse', data);
}

function draw() {
	newDrawing(data);
	mouseDragged();
	
}

function changeBack(){
  var back = random(255);
  background(back);
}
	
	
